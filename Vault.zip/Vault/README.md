React chatting app working in Vite with HMR and some ESLint rules.

npm install (to install node modules)
npm run dev






